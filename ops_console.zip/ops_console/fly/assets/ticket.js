/* Ticket page
   - Reads session state (storage.js)
   - Allows OPS/Admin override by URL params:
     ?ref=FSB-123&status=paid&from=...&to=...&date=...&dep=...&arr=...&flight=...
*/
const state = initState();
const $ = (s) => document.querySelector(s);

function qp(name){
  try { return new URLSearchParams(location.search).get(name); } catch { return null; }
}

function setText(id, val){
  const el = document.getElementById(id);
  if (el) el.textContent = (val === undefined || val === null || val === "") ? "—" : String(val);
}

(function hydrate(){
  const ref = qp("ref") || state.bookingRef || "—";
  const st = (qp("status") || state.paymentStatus || "pending").toLowerCase();
  const statusLabel = (st === "paid" || st === "confirmed") ? "CONFIRMED" : "PENDING";

  // prefer URL overrides, then session state
  const from = qp("from") || state.from || "—";
  const to = qp("to") || state.to || "—";
  const date = qp("date") || state.selected?.dateStr || state.date || "—";
  const dep = qp("dep") || state.selected?.start || "—";
  const arr = qp("arr") || state.selected?.end || "—";
  const flight = qp("flight") || state.selected?.flightNo || "FSB";

  const pax0 = (Array.isArray(state.passengers) && state.passengers[0]) ? state.passengers[0] : null;
  const passenger = qp("passenger") || (pax0 ? `${pax0.firstName || pax0.first || ""} ${pax0.lastName || pax0.last || ""}`.trim() : "") || "—";

  setText("tRef", ref);
  setText("tStatus", statusLabel);
  setText("tFrom", from);
  setText("tTo", to);
  setText("tDate", date);
  setText("tDep", dep);
  setText("tArr", arr);
  setText("tFlight", flight);
  setText("tPassenger", passenger);

  const qr = document.getElementById("tQR");
  if (qr) qr.textContent = ref;

  // warn message
  const warn = document.getElementById("tWarn");
  if (warn){
    warn.textContent = (statusLabel === "CONFIRMED")
      ? "Ticket confirmed. Print / Save PDF for boarding."
      : "This ticket is not confirmed yet. Complete payment / OPS confirmation to issue the final ticket.";
  }

  const printBtn = document.getElementById("printBtn");
  if (printBtn) printBtn.onclick = () => window.print();
})();
