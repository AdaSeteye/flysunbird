const COUNTRIES = ['Tanzania','Kenya','Uganda','Rwanda','Ethiopia','United States','United Kingdom'];
