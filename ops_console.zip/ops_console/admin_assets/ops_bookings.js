// Ops-side storage for captured bookings (until backend is wired).
// This is NOT "test codes". It's the same fields your client collects.
// Later we swap these functions to call FastAPI endpoints without changing UI.

const OpsBookings = (() => {
  const KEY = "flysunbird_ops_bookings_v1";
  const API_BASE = (window.API_BASE || localStorage.getItem("FSB_API_BASE") || "").replace(/\/$/,"");
  const API_TOKEN = (localStorage.getItem("FSB_TOKEN") || "");
  const api = async (method, path, body) => {
    if(!API_BASE) throw new Error("API_BASE not set");
    const res = await fetch(API_BASE + path, {method, headers:{ "Content-Type":"application/json", ...(API_TOKEN?{"Authorization":"Bearer "+API_TOKEN}:{}) }, body: body?JSON.stringify(body):undefined});
    if(!res.ok) throw new Error(await res.text());
    return await res.json();
  };

  const uid = () => `bk_${Math.random().toString(16).slice(2)}_${Date.now().toString(16)}`;

  function load(){
    try{
      const raw = localStorage.getItem(KEY);
      return raw ? JSON.parse(raw) : [];
    }catch(e){ return []; }
  }
  function save(list){ localStorage.setItem(KEY, JSON.stringify(list)); }

  function add(b){
    const list = load();
    const now = new Date().toISOString();
    const x = {
      id: uid(),
      createdAt: now,
      status: "PENDING", // PENDING | CONFIRMED | CANCELLED | FAILED
      paymentStatus: "UNPAID", // UNPAID | PAID | FAILED | REFUNDED
      ...b
    };
    list.unshift(x);
    save(list);
    return x;
  }

  function update(id, patch){
    const list = load();
    const x = list.find(i=>i.id===id);
    if(!x) return null;
    Object.assign(x, patch, {updatedAt: new Date().toISOString()});
    save(list);
    return x;
  }

  function remove(id){
    const list = load().filter(i=>i.id!==id);
    save(list);
    return true;
  }

async function listRemote(){
  return await api("GET","/ops/bookings");
}
async function getRemote(ref){
  return await api("GET", `/ops/bookings/${ref}`);
}
async function createDraftRemote(payload){
  return await api("POST","/ops/bookings/create-draft", payload);
}
async function paymentLinkRemote(ref){
  return await api("GET", `/ops/bookings/${ref}/payment-link`);
}
async function cancelRemote(ref, reason){
  return await api("POST", `/ops/bookings/${ref}/cancel`, {reason: reason || ""});
}
async function refundRemote(ref, payload){
  return await api("POST", `/ops/bookings/${ref}/refund`, payload);
}

function reset(){


    localStorage.removeItem(KEY);
    return [];
  }

  return { load, save, add, update, remove, reset, listRemote, getRemote, createDraftRemote, paymentLinkRemote, cancelRemote, refundRemote };
})();